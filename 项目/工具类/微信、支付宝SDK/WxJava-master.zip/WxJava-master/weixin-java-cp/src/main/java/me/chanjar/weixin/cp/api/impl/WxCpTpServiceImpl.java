package me.chanjar.weixin.cp.api.impl;

/**
 * <pre>
 *  默认接口实现类，使用apache httpclient实现
 * Created by zhenjun cai.
 * </pre>
 *
 * @author zhenjun cai
 */
public class WxCpTpServiceImpl extends WxCpTpServiceApacheHttpClientImpl {
}
