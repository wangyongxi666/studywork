package me.chanjar.weixin.cp.api;

/**
 * <pre>
 * 仅供测试使用的一些常量
 * Created by Binary Wang on 2017-3-9.
 * </pre>
 */
public class TestConstants {
  ///////////////////////
  // 文件类型
  ///////////////////////
  public static final String FILE_JPG = "jpeg";
  public static final String FILE_MP3 = "mp3";
  public static final String FILE_AMR = "amr";
  public static final String FILE_MP4 = "mp4";
}
