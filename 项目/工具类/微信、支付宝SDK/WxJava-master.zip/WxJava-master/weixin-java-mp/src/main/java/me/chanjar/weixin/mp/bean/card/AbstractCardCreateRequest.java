package me.chanjar.weixin.mp.bean.card;

import lombok.Data;

import java.io.Serializable;

/**
 * .
 *
 * @author leeis
 * @date 2018/12/29
 */
@Data
public abstract class AbstractCardCreateRequest implements Serializable {
  private static final long serialVersionUID = -260291223712818801L;

}
