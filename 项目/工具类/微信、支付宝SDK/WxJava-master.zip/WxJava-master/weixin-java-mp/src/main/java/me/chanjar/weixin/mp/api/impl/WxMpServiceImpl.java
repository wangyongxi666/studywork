package me.chanjar.weixin.mp.api.impl;

/**
 * <pre>
 * 默认接口实现类，使用apache httpclient实现
 * Created by Binary Wang on 2017-5-27.
 * </pre>
 *
 * @author <a href="https://github.com/binarywang">Binary Wang</a>
 */
public class WxMpServiceImpl extends WxMpServiceHttpClientImpl {
}
