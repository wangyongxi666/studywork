
### Demo项目
在码云和GitHub上均可访问，会保持同步，请根据自己情况选用，欢迎提供更多的demo实现。

1. 微信支付Demo：[码云](http://gitee.com/binary/weixin-java-pay-demo)、[GitHub](http://github.com/binarywang/weixin-java-pay-demo)
1. 企业号/企业微信Demo：[码云](http://gitee.com/binary/weixin-java-cp-demo)、[GitHub](http://github.com/binarywang/weixin-java-cp-demo)
1. 微信小程序Demo：[码云](http://gitee.com/binary/weixin-java-miniapp-demo)、[GitHub](http://github.com/binarywang/weixin-java-miniapp-demo)
1. 开放平台Demo：[码云](http://gitee.com/binary/weixin-java-open-demo)、[GitHub](http://github.com/Wechat-Group/weixin-java-open-demo)
1. 公众号Demo：
	- 使用Spring MVC实现的公众号Demo：[码云](http://gitee.com/binary/weixin-java-mp-demo-springmvc)、[GitHub](http://github.com/binarywang/weixin-java-mp-demo-springmvc)
	- 使用Spring Boot实现的公众号Demo：[码云](http://gitee.com/binary/weixin-java-mp-demo-springboot)、[GitHub](http://github.com/binarywang/weixin-java-mp-demo-springboot)
	- 含公众号和部分微信支付代码的Demo：[码云](http://gitee.com/binary/weixin-java-tools-springmvc)、[GitHub](http://github.com/Wechat-Group/weixin-java-tools-springmvc)
