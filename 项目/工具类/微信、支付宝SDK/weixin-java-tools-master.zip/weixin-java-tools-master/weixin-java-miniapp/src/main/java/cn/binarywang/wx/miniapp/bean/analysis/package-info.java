/**
 * 数据分析
 *
 * @author <a href="https://github.com/charmingoh">Charming</a>
 * @since 2018-04-28
 */
package cn.binarywang.wx.miniapp.bean.analysis;
