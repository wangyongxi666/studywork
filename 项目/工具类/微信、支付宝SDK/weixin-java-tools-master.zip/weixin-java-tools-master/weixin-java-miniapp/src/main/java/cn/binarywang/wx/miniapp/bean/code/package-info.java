/**
 * 微信小程序代码管理相关的 bean
 *
 * @author <a href="https://github.com/charmingoh">Charming</a>
 * @since 2018-04-26 19:44
 */
package cn.binarywang.wx.miniapp.bean.code;
