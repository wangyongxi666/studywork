# best-pay-demo
本示例演示了如何调用[best-pay-sdk](https://github.com/Pay-Group/best-pay-sdk)

#### 项目说明
1. 需要在Jdk版本>1.8上运行
2. 本项目采用SpringBoot1.5.1开发

#### 运行示例
1. 运行前需要先配置好密钥, 见`PayConfig.java`
2. 运行项目
3. 浏览器访问http://127.0.0.1:8080
4. 查看日志
